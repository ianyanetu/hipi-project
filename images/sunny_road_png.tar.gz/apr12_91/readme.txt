Motion Sequence: 67 frames of a sunny 1-lane road

Image: 240x256 color

Additional: results
